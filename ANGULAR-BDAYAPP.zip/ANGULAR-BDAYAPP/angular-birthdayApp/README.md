##Installation.
Please run "nmp install" on the root of the project folder so all the supporting node packages are installed.
note.: Am using a pre-existing package.json for this project, which might have few packages that are not used or required.

##Using a lite Webserver.
To avoid setup of Webserver and configering it. AM using a lite webserver, which should be installed along with otehr node packages.

##Using Gulp as Task Runner.
Please execute command "gulp" on terminal or command prompt to run the application and you can see the application on the browser on the local host.

## Text Editor used
I have used Visual Code as my text editor...

##Project Pattern.
I have followed John Papa's style guide for building the modules and also followed a modular pattern to group controllers, components, services, filters and Root Module.

##Testing.
I have writen Unit test cases for Testing Controller and its functions as well as Filter. I have used Jasmin, Karma as test runner and Phantom as my headless browser, so you see all the results in terminal itself.
User "karma start" command in browser

##Styles
I am using Bootstrap 4. However, applicaiton might not be responsive and there might be some Styling issues....



