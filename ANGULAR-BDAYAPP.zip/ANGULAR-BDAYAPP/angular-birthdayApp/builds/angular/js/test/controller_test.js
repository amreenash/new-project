describe('Controller Testing - bdFormController', function() {
    beforeEach(module('bd.Controllers'));
    
    var formController, dataService;
  
    beforeEach(inject(function($controller, $injector){
      dataService = MockStringService = $injector.get('dataService'); 
      formController = $controller('bdFormController', {dataService: dataService});
      formController.person = {name:'test', dateOfBirth: '01-01-1989'};
    }));
  
    it('bdFormController controller instantiation', function (){
        expect(formController).toBeDefined();
    });
    it('bdFormController controller SavebdData with  invalid form' , function (){
        formController.savebdData(false);
        expect(dataService.bdData[0].BirthDays.length).toBe(0);
    });
    //This test case is also testing the DataService function...
    it('bdFormController controller SavebdData with valid form', function (){
        formController.savebdData(true);
        expect(dataService.bdData[0].BirthDays.length).toBe(1);
    });
    it('bdFormController testing data saved in dataService.bdData', function (){
        formController.savebdData(true);
        expect(dataService.bdData[0].BirthDays[0].name).toBe('test');
    });
  });

  describe('Controller Testing - bdMonthController', function() {
    beforeEach(module('bd.Controllers'));
    
    var monthController, dataService;
    
      beforeEach(inject(function($controller, $injector, $filter){
        dataService = MockStringService = $injector.get('dataService'); 
        monthController = $controller('bdMonthController', {$filter: $filter, dataService: dataService});
        monthController.person = {name:'test', dateOfBirth: '01-01-1989'};
      }));
  
    it('bdMonthController controller instantiation', function (){
        expect(monthController).toBeDefined();
    });
    it('bdMonthController controller onOptionChange - Order by month, direction asc', function (){
        monthController.orderDirection = 'asc';
        var option = {label: 'Order By Month'};
        monthController.onFilterOptionChange(option);
        expect(monthController.bdData[0].month).toBe('January');
    });
    it('bdMonthController controller onOptionChange - Order by month, direction desc', function (){
        monthController.orderDirection = 'desc';
        var option = {label: 'Order By Month'};
        monthController.onFilterOptionChange(option);
        expect(monthController.bdData[0].month).toBe('December');
    });
    it('bdMonthController controller onOrderDirectionChange - direction', function (){
        monthController.onOrderDirectionChange('desc');
        expect(monthController.bdData[0].month).toBe('December');
        monthController.onOrderDirectionChange('asc');
        expect(monthController.bdData[0].month).toBe('January');
    });

  });

