describe('Filters', function(){ //describe your object type
    beforeEach(module('bd.Filters')); //load module
    describe('OrderByValue',function(){ //describe your app name
        var filter;
        
        var bdData = [
        {
            id:2,
            month: 'February',
            image: '',
            BirthDays:[]
        },
        {
            id:3,
            month: 'March',
            image: '',
            BirthDays:[{name:'sample'}, {name:'sample2'}]
        
        },
        {
            id:1,
            month: 'January',
            image: '',
            BirthDays:[{name:'sample'}]
        }];
        
        beforeEach(inject(function($filter){ 
            //initializing orderByValue filter
            filter = $filter('orderByValue',{});
        }));
        //Tests for functioning of filter - Order By Month
        it('Should Order the data by month', function(){  
            filter(bdData, 'Order By Month');
            expect(bdData[0].month).toBe('January'); 
        });

        it('Should Order the data by month in desc', function(){ 
            filter(bdData, 'Order By Month', 'desc');
            expect(bdData[0].month).toBe('March'); //pass
        });

        it('Should Order the data by month in asc', function(){ 
            filter(bdData, 'Order By Month', 'asc');
            expect(bdData[0].month).toBe('January'); //pass
        });
        
        //Tests for functioning of filter - Order By no. of Birthdays
        it('Should Order the data by no. of Birthdays', function(){ 
            filter(bdData, 'Order By Birthday Count' );
            expect(bdData[0].month).toBe('February'); //pass
        });
        it('Should Order the data by no. of Birthdays in desc', function(){ 
            filter(bdData, 'Order By Birthday Count', 'desc' );
            expect(bdData[0].month).toBe('March'); //pass
        });
        it('Should Order the data by no. of Birthdays in asc', function(){ 
            filter(bdData, 'Order By Birthday Count', 'asc' );
            expect(bdData[0].month).toBe('February'); //pass
        });
        //'Order By Birthday Count'
    });
});