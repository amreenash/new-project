//Created a Module to represent all the Filters that are part of the applicaiton.
angular.module('bd.Filters', []);
angular.module('bd.Filters').filter('orderByValue', function () {
    // custom value function for sorting based on order by option selected and direction (asc or desc)
    return orderByValueOptions;
  });
  function orderByValueOptions (input, option, direction){
      
      //Checks what is the orderby based on
      switch(option){
          case 'Order By Month': 
            input.sort(function(a, b){
                return a.id - b.id;
            });
          break;
          case 'Order By Birthday Count':
          //Sorting based on no. of birthdays for that month and order the months in asc -
            input.sort(function(a, b){
                var x = a.BirthDays.length - b.BirthDays.length;
                return x === 0? a.id - b.id : x;
            });
          break;
      }
      //checks if the direction is desc - and reverses the array if its 'desc'
      if(direction === 'desc'){
        input.reverse();
      }
      return input;
  }

  