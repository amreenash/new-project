//Created a Mroot module of the applicaiton.
angular.module('bd', [
    'ngRoute',
    'bd.Controllers',
    'bd.Components',
    'bd.Services',
    'bd.Filters'
]);

//Configering route using $routeProvider
angular.module('bd').config(['$routeProvider', function($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl: 'js/partials/bd-form.html',
            controller: 'bdFormController',
            controllerAs: 'fc'
        })
        .when('/details', {
            templateUrl: 'js/partials/monthly-details.html',
            controller: 'bdMonthController',
            controllerAs: 'mc'
        })
        .otherwise({
            templateUrl: 'js/partials/bd-form.html',
            controller: 'bdFormController',
            controllerAs: 'fc'
        });
}]);