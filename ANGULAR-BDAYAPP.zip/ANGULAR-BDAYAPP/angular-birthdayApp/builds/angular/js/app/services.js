//Created a Module to represent all the controllers that are part of the applicaiton.
angular.module('bd.Services', []);
angular.module('bd.Services').factory('dataService', bdDataService);
function bdDataService(){
    //Data object that can be shared accross the applicaiton
    var bdData = [{
        id:1,
        month: 'January',
        image: '',
        BirthDays:[]
    },
    {
        id:2,
        month: 'February',
        image: '',
        BirthDays:[]
    },
    {
        id:3,
        month: 'March',
        image: '',
        BirthDays:[]
    },
    {
        id:4,
        month: 'April',
        image: '',
        BirthDays:[]
    },
    {
        id:5,
        month: 'May',
        image: '',
        BirthDays:[]
    },
    {
        id:6,
        month: 'June',
        image: '',
        BirthDays:[]
    },
    {
        id:7,
        month: 'July',
        image: '',
        BirthDays:[]
    },
    {
        id:8,
        month: 'August',
        image: '',
        BirthDays:[]
    },
    {
        id:9,
        month: 'September',
        image: '',
        BirthDays:[]
    },
    {
        id:10,
        month: 'October',
        image: '',
        BirthDays:[]
    },
    {
        id:11,
        month: 'November',
        image: '',
        BirthDays:[]
    },
    {
        id:12,
        month: 'December',
        image: '',
        BirthDays:[]
    }];

    //Function that is responsible for adding form data to the bdData object.
    function savebdData(data){
        
        var month = data.dateOfBirth.split('-')[1];
        var monthOfBirth = this.bdData.filter(function(item){
            return item.id == month;
        });
        monthOfBirth[0].BirthDays.push(data);
    }

    return{
        bdData: bdData,
        saveBirthDayData : savebdData
    };
}