
//Created a Module to represent all the Components and directives that are part of the applicaiton.
angular.module('bd.Components', []);

// BirthMonth Card directive
angular.module('bd.Components').directive("bdMonthCard", monthlyDetails);
angular.module('bd.Components').directive("bdDropdown", dropDown);

// BirthMonth Card directive function
function monthlyDetails(){
    return{
        restrict: 'AE',
        scope:{
            item:'='
        },
        templateUrl:'js/partials/monthly-card.html'
    };
}
//Created a Dropdown Directive to create a reusable component.
function dropDown(){
    return{
        restrict: 'AE',
        scope:{
            options:'=',
            selectedOption:'=',
            onSelectChange: '&' // Pass callback function to be called on dropdown option selection change
        },
        template:'<div class="btn-group">'+
                    '<button type="button" class="btn btn-secondary">{{selectedOption.label}}</button>'+
                    '<button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">'+
                        '<span class="sr-only">Toggle Dropdown</span>'+
                    '</button>'+
                    '<div class="dropdown-menu">'+
                        '<a class="dropdown-item" ng-repeat="option in options" ng-click=onSelection(option)>{{option.label}}</a>'+
                    '</div>'+
                    '</div>',
        link: dropDownLink
    };
}
//Dropdown directive link function
function dropDownLink(scope, ele, attr){
   //Created an event to capture the dropdown option change.
    scope.onSelection = onOptionSelection;

    function onOptionSelection(option){
        scope.selectedOption = option;
        //Calls the callback function that is passed by the parent
        scope.onSelectChange({option: option});
    }
}

