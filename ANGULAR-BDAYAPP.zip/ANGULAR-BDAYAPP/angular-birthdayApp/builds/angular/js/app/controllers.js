//Created a Module to represent all the controllers that are part of the applicaiton.
angular.module('bd.Controllers', ['bd.Services', 'bd.Filters']);

//Controller for BirthDay Form
angular.module('bd.Controllers').controller('bdFormController', formController);
//Controller for Birth - Month form
angular.module('bd.Controllers').controller('bdMonthController', monthController);

//BirthDay Form controller function
function formController($filter, dataService) {
  var vm = this;
  vm.testVar = 'test';
  //vm.currentDate = $filter('date')(new Date(), 'yyyy-MM-dd');
  //Regex to determine the pattern required for Date input
  vm.dateRegex = new RegExp(['^(?:(?:(?:0?[13578]|1[02])(|-|)31)', '\\1|(?:(?:0?[1,3-9]|1[0-2])(|-|)(?:29|30)', '\\2))(?:(?:1[6-9]|[2-9]\\d)?\d{2})$|^(?:0?2(|-|)', '29\\3(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|', '[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))', '$|^(?:(?:0?[1-9])|(?:1[0-2]))(|-|)', '(?:0?[1-9]|1\\d|2[0-8])\\4', '(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$'].join(''),"g");
  vm.savebdData = saveBirthdayData;
//Function calls the DataServeice to save the FormData.
  function saveBirthdayData(isDataValid){
    if(isDataValid){
      dataService.saveBirthDayData(vm.person);
      vm.person=null;
    }
  }
}

//Birth Months COntroller function
function monthController($filter, dataService) {
  var vm = this;
  vm.filterOptions = [{label:'Order By Month'}, {label:'Order By Birthday Count'}];
  vm.selectedFilterOption = vm.filterOptions[0];
  vm.bdData = dataService.bdData;
  vm.onFilterOptionChange = onOptionChange;
  vm.bdData = $filter('orderByValue')(dataService.bdData, vm.selectedFilterOption.label);
  vm.orderDirection = 'asc';
  vm.onOrderDirectionChange = onOrderDirectionChange;

  //Functions
  // This function is triggered when the dropdown options are changed
  function onOptionChange(option){
    //Using a custom filter to order the months data based on sort order and direction.
    vm.bdData = $filter('orderByValue')(dataService.bdData, option.label, vm.orderDirection);
  }
  //This function is triggered when the ASC or DESC (direction) changed
  function onOrderDirectionChange(direction){
    vm.bdData.reverse();
  }
  
  
}
